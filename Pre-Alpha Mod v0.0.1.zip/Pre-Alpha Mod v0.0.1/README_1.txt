# Slime Rancher Pre-Alpha Mod v0.0.1
**by Furkaiko**

The world's first mod for Slime Rancher Pre-Alpha v0.2.1 (December 2015).

---

## Features
- **Noclip / Free Fly** — F5 to toggle, Space/LCtrl to move up/down
- **Spawn any Slime** — including Largos, Gold Slime, Tarr
- **Spawn Gordos** — all gordos in the scene
- **Food to inventory** — add any food directly
- **Special items** — spawn keys, crates, plorts
- **Cheat menu** — money, energy, health, radiation, keys, upgrades
- **Unlock all** — unlock all areas
- **Day/Night control**
- **Time speed control**
- **Multi-language** — English, Turkish, Spanish

## Controls
| Key | Action |
|-----|--------|
| F4 | Open/Close menu |
| F5 | Toggle Noclip |
| F6 | Refresh/Rescan |

---

## Installation

### Requirements
- Slime Rancher Pre-Alpha v0.2.1 only
- Windows

### Steps
1. Download `Noclip.dll` and `Assembly-CSharp.dll`
2. Go to your Slime Rancher Pre-Alpha folder
3. Place `Noclip.dll` here:
```
SlimeRancher_Data\Managed\Noclip.dll
```
4. Replace the existing `Assembly-CSharp.dll` with the one provided here:
```
SlimeRancher_Data\Managed\Assembly-CSharp.dll
```
5. Launch the game and press **F4** to open the menu!

---

## Notes
- This mod only works with Pre-Alpha v0.2.1
- Back up your original `Assembly-CSharp.dll` before replacing
- Gordo tab requires entering an area with Gordos first, then press F6 to scan

---

## Interesting Findings
- **Hunter Slime** exists in the files but uses the Tabby Slime model — camouflage mechanic not yet implemented
- **Prickle Pear** exists in the files since v0.2.1, long before its official release
- **The Pit** expansion exists in code but was removed before this version
- **Rad Slime** exists despite Indigo Quarry being removed in v0.2.0

---

## Reddit Post
[Hunter Slime Prototype Found in Slime Rancher Pre-Alpha v0.2.1](https://www.reddit.com/r/slimerancher/comments/1toddbv/hunter_slime_prototype_found_in_slime_rancher/)
